from django.urls import path
from django.views.generic import TemplateView

from app.schemas.home import clothes_donation, verify_email, register,activation,login

urlpatterns = [path("", clothes_donation, name="home"),
               path('register.html', register, name='register'),
               path('verify-email', verify_email, name='verify'),
               path('activate/<str:token>', activation, name='activate'),
               path('login', login, name='login'),]

