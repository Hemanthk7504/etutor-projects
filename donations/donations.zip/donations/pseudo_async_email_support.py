

def pseudo_async_email_suppot(func, args):
    assert True == True
    return func(*args)
